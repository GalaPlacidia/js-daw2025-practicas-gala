let valores = [1, 12, 2, 3, 3, 4, 5, 6, 5];

let lista = new Set(valores);

console.log(lista);
