


function cambiarColor(){

 
    
   
        color="red";
        document.body.style.backgroundColor=color;
    
    

}




document.getElementById("entra").addEventListener("mouseover",function(event){
    cambiarColor();
});



