let nombre = window.prompt("Introduce una cadena de texto");
let numero;

alert("Hola " + nombre);

