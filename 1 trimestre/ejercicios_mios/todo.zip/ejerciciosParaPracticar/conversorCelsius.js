let array = [10, 12, 18, -2, 5];

array.map(function (num) {
  return num * (9 / 5) + 32;
});

let nombres = ['ana', 'luis', 'rita', 'pepe'];

nombres.map(function (nombre) {
  nombre.charAt[0].toUpperCase();
});
