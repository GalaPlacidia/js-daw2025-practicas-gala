function mostrarCoordenadas(evento) {
  if (evento.type == 'mouseover') {
    document.getElementById('parrafo').innerHTML =
      'CoordenadaX: ' + evento.clientX + ' Coordenada Y: ' + evento.clientY;
  }
}

//SI NO AÑADO EL EVENT LISTENER NO HAGO NADA!!
document.addEventListener('mouseover', mostrarCoordenadas);
