/*Crea una función anónima autoinvocada que defina una variable privada llamada balance inicializada en 1000. Esta IIFE debe devolver una función que permita hacer dos cosas cada vez que la llames:

Recibir un parámetro que indique una cantidad de dinero.

Sumar o restar esa cantidad al balance según si es positivo o negativo.

Devolver el nuevo valor del balance.

Luego, prueba llamar a esta función varias veces con diferentes cantidades para simular depósitos y retiros, y verifica que el balance se actualiza correctamente./*

*/

let dinero = (function () {
  let balance = 1000;

  return function (cantidad) {
    if (cantidad < 0) {
      //OJO!! QUE SI PONES BALANCE -=CANTIDAD SUMAS LA CANTIDAD EN VEZ DE RESTAR!!!!
      balance += cantidad;
      return balance;
    }

    if (cantidad > 0) {
      balance += cantidad;
      return balance;
    } else {
      console.log('Escribe alguna cantidad');
    }
  };
})();

console.log(dinero(500));
console.log(dinero(0));
console.log(dinero(-500));
console.log(dinero(-500));
