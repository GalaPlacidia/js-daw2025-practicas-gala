

function filtro(array,callback){
    array.filter(x=>x*2)
    
}