let personas = new Map();

personas.set('Eva', 18);
personas.set('Diego', 90);
personas.set('Olivia', 9);

personas.set('Olivia', 10);

console.log(personas);
