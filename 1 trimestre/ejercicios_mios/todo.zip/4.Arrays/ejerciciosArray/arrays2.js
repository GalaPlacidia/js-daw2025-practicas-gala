let letras = new Array();

letras.unshift('C');
letras.unshift('B');
letras.unshift('A');
letras.push('D');
letras.push('E');
letras.push('F');

console.log(letras);

letras.pop();
letras.shift();

console.log(letras);
