let numeros = [1, 2, 3, 4, 5, 6];

[uno, dos, ...resto] = numeros;

console.log(uno);
console.log(dos);
console.log(resto);
console.log(numeros);
