let paises = ['España', 'Francia', 'Alemania', 'Italia'];

for (let i = 0; i < paises.length; i++) {
  console.log(paises[i]);
}

paises.shift();

console.log(paises);
